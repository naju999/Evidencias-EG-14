document.getElementById("cambiarFondo").addEventListener("click",
    function() {
     document.body.style.backgroundColor = "lightblue";
    });